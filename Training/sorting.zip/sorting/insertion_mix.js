var arr = ["A", "M", "C", 1.5, 3, 8]
var len = arr.length

function smallValue(val1, val2) {
    val1 = val1.charCodeAt()
    val2 = val2.charCodeAt()

    if (val1 > 97) {
        norm1 = val1 - 97
    } else {
        norm1 = val1 - 65
    }
    if (val2 > 97) {
        norm2 = val2 - 97
    } else {
        norm2 = val2 - 65
    }
    if (typeof val1 === "number") {
        norm1 = val1
    }
    if (typeof val2 === "number") {
        norm1 = val1
    }

    console.log(val1, val2, norm1, norm2);
    if (norm1 == norm2 && val2 < val1) {
        return true
    } else if (norm1 < norm2) {
        return true
    }
    return false

}
for (i = 0; i < len; i++) {
    let temp = arr[i]
    j = i - 1
    while (j >= 0 && arr[j] > temp) {
        smallValue(arr[j + 1], arr[j]);
        j = j - 1;
    }
    arr[j + 1] = temp;
    //  console.log("old ", arr);
}
console.log("insertion ", arr);